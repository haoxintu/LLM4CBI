# oclint-json-compilation-database

[![Travis CI Status](https://api.travis-ci.org/oclint/oclint-json-compilation-database.svg?branch=master)](https://travis-ci.org/oclint/oclint-json-compilation-database)

compile_commands.json is a JSON format compilation database. It maintains a list
of sources with their build options.

OCLint can leverage the information from this file to facilitate the inspection
process.

oclint-json-compilation-database helps extract and filter information from
compile_commands.json, and invoke OCLint under the hook for analysis.

Visit http://oclint.org/docs/manual/oclint-json-compilation-database.html
for documentation about using oclint-json-compilation-database.
