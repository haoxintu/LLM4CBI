#include "oclint/AbstractASTMatcherRule.h"
#include "clang/Lex/Lexer.h"

#include <iostream>
namespace oclint
{

/*virtual*/
AbstractASTMatcherRule::~AbstractASTMatcherRule() {}

/*virtual*/
void AbstractASTMatcherRule::run(const clang::ast_matchers::MatchFinder::MatchResult &result)
{
    callback(result);
}

/*virtual*/
void AbstractASTMatcherRule::setUp()
{
    _finder = new clang::ast_matchers::MatchFinder();
    setUpMatcher();
}

bool AbstractASTMatcherRule::VisitDecl(clang::Decl *decl)
{
    _finder->match(*decl, *_carrier->getASTContext());
    return true;
}

bool AbstractASTMatcherRule::VisitStmt(clang::Stmt *stmt)
{
    //clang::ASTContext &context = *_carrier->getASTContext();
    _finder->match(*stmt, *_carrier->getASTContext());
    //clang::ASTContext context = *_carrier->getASTContext();
    //std::cout << "executed ? ";
    //clang::SourceManager sourceManager = context.getSourceManager();
    //const char* for_str = "ForStmt";
    //const char* stmt_str = stmt->getStmtClassName();
    //if (for_str == stmt_str)
    //llvm::outs() << "Stmt type : " << stmt->getStmtClassName() << "\n";
    return true;
}

/*virtual*/
void AbstractASTMatcherRule::tearDown()
{
    delete _finder;
    _finder = nullptr;
}

} // end namespace oclint
