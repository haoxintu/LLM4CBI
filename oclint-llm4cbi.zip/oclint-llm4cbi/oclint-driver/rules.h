#include <string>

void dynamicLoadRules(std::string ruleDirPath);
