#include "oclint/metric/CyclomaticComplexityMetric.h"
#include <iostream>
#include <clang/Frontend/CompilerInstance.h>
#include <llvm/Support/FileSystem.h>
#include <clang/Basic/FileEntry.h>
#include <clang/Basic/FileManager.h>

#include "/media/haoxin/sam-disk/fl-compiler/oclint/oclint-rules/include/oclint/AbstractASTRuleBase.h"
#include "/media/haoxin/sam-disk/fl-compiler/oclint/oclint-rules/include/oclint/helper/SuppressHelper.h"
#include "/media/haoxin/sam-disk/fl-compiler/oclint/oclint-core/include/oclint/RuleCarrier.h"
#include "/media/haoxin/sam-disk/fl-compiler/oclint/oclint-core/include/oclint/RuleBase.h"

#include "llvm/Support/CommandLine.h"
#include "clang/Basic/LangOptions.h"
#include "clang/Frontend/CompilerInstance.h"
#include "clang/Frontend/FrontendActions.h"
#include "clang/Frontend/TextDiagnosticPrinter.h"
#include "clang/Tooling/Tooling.h"
#include <clang/AST/ASTContext.h>


using namespace oclint;

static clang::ASTContext* g_context;

int CyclomaticComplexityMetric::calculate(clang::Decl *decl)
{
    _count = 0;
    //std::cout << " in calculate " << std::endl;
    clang::ASTContext &context = decl->getASTContext();
    g_context = &context;
    (void) /* explicitly ignore the return of this function */ TraverseDecl(decl);
    return _count + 1;
}

bool CyclomaticComplexityMetric::VisitIfStmt(clang::IfStmt * stmt)
{
    _count++;
    //std::cout << "### if complexity : " << _count << std::endl;
    std::cout << stmt << " if " << _count << " ";
    clang::SourceManager& sourceManager = g_context->getSourceManager();
    std::cout << sourceManager.getExpansionLineNumber(stmt->getBeginLoc()) << " " <<
        sourceManager.getExpansionLineNumber(stmt->getEndLoc()) << "\n";
    return true;
}

bool CyclomaticComplexityMetric::VisitForStmt(clang::ForStmt * stmt)
{
    _count++;
    std::cout << stmt << " for " << _count << " ";
    clang::SourceManager& sourceManager = g_context->getSourceManager();
    std::cout << sourceManager.getExpansionLineNumber(stmt->getBeginLoc()) <<  " " <<
        sourceManager.getExpansionLineNumber(stmt->getEndLoc()) << "\n";
    //std::cout << "Statement " << sourceManager.getExpansionLineNumber(stmt->getBeginLoc()) << "-" <<
    //    sourceManager.getExpansionLineNumber(stmt->getEndLoc()) << ": " << sourceManager.getCharacterData(stmt->getBeginLoc()) << "\n";
    return true;
}

bool CyclomaticComplexityMetric::VisitObjCForCollectionStmt(clang::ObjCForCollectionStmt *)
{
    _count++;
    return true;
}

bool CyclomaticComplexityMetric::VisitWhileStmt(clang::WhileStmt * stmt)
{
    _count++;
    std::cout << stmt << " while " << _count << " ";
    clang::SourceManager& sourceManager = g_context->getSourceManager();
    std::cout << sourceManager.getExpansionLineNumber(stmt->getBeginLoc()) << " " <<
        sourceManager.getExpansionLineNumber(stmt->getEndLoc()) << "\n";
    return true;
}

bool CyclomaticComplexityMetric::VisitDoStmt(clang::DoStmt * stmt)
{
    _count++;

    std::cout << stmt << " do " << _count << " ";
    clang::SourceManager& sourceManager = g_context->getSourceManager();
    std::cout << sourceManager.getExpansionLineNumber(stmt->getBeginLoc()) << " " <<
        sourceManager.getExpansionLineNumber(stmt->getEndLoc()) << "\n";
    return true;
}

bool CyclomaticComplexityMetric::VisitCaseStmt(clang::CaseStmt * stmt)
{
    _count++;

    /*
    std::cout << "case " << _count << " ";
    clang::SourceManager& sourceManager = g_context->getSourceManager();
    std::cout << sourceManager.getExpansionLineNumber(stmt->getBeginLoc()) << " " <<
        sourceManager.getExpansionLineNumber(stmt->getEndLoc()) << "\n";*/
    return true;
}

bool CyclomaticComplexityMetric::VisitObjCAtCatchStmt(clang::ObjCAtCatchStmt *)
{
    _count++;
    return true;
}

bool CyclomaticComplexityMetric::VisitCXXCatchStmt(clang::CXXCatchStmt *)
{
    _count++;
    return true;
}

bool CyclomaticComplexityMetric::VisitConditionalOperator(clang::ConditionalOperator *)
{
    _count++;
    return true;
}

bool CyclomaticComplexityMetric::VisitBinaryOperator(clang::BinaryOperator *binaryOperator)
{
    if (binaryOperator->getOpcode() == clang::BO_LAnd ||
        binaryOperator->getOpcode() == clang::BO_LOr)
    {
        _count++;
    }
    return true;
}

extern "C" int getCyclomaticComplexity(clang::Decl *decl)
{
    CyclomaticComplexityMetric ccnMetric;
    return ccnMetric.calculate(decl);
}
