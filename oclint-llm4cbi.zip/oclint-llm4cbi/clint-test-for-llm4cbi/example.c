short s;
int a;
int b;
int c;
volatile int v;
static int u[] = { 0, 0, 0, 0, 0, 1 };

void foo() {
  int i = 1;
  int j;
  for (; b <= 0; ++b) {
    int k;
    int d = 0;
    for (; d <= 5; d++) {
      int *l = &c;
      int e = 0;
      for (; e <= 0; e++) {
        int *m = &k;
        unsigned int n = u[d];
        i = a ? n : n / a;
        j = s ? 0 : (1 >> v);
        *m = j;
	 if (a) {
  printf("%d \n", a);
    }
      }
      do {
        c = a +b ;
      }
      while(a >0);
      *l = k < i;
    }
  }
}
int main() {
  foo();
    if (a) {
  printf("%d \n", a);
    }
  return 0;
}
