# -*- coding: utf-8 -*-

import sys
import re
import os

def write_dict_to_file(filename, my_dict):
    with open(filename, 'w') as f:
        for key, value in my_dict.items():
            f.write(str(key) + '\n')
            if isinstance(value, list):
                for item in value:
                    f.write(str(item) + '\n')
            else:
                f.write(str(value) + '\n')
            f.write('\n')

def data_flow_analysis(src_file):
    # Create an empty dictionary to store the data
    data_dict = {}

    # get the dict from srcSlice
    os.system("cp {} example.c".format(src_file))
    os.system("srcml ./example.c --position -o example.c.xml")
    os.system("srcslice example.c.xml > example.c.dict")

    # Open the text file for reading
    with open('example.c.dict', 'r') as f:
        # Initialize variables to store the data for each item
        name = ''
        dvars = set()
        aliases = set()
        use = set()
        definition = set()
        edges = set()

        # Iterate over each line in the file
        for line in f:
            # Strip whitespace from the line
            line = line.strip()

            # Check if the line contains the name of an item
            if line.startswith('Name: '):
                # If it does, store the name in the name variable
                name = line.split('Name: ')[1].strip()

            # Check if the line contains the set of defined variables for an item
            elif line.startswith('Dvars: '):
                # If it does, store the set of variables in the dvars variable
                dvars = set(line.split('Dvars: ')[1].strip("{}").split(','))
                dvars.discard('')
                # print("dvar : ", dvars)

            # Check if the line contains the set of aliases for an item
            elif line.startswith('Aliases: '):
                # If it does, store the set of aliases in the aliases variable
                aliases = set(line.split('Aliases: ')[1].strip("{}").split(','))
                aliases.discard('')

            # Check if the line contains the set of used variables for an item
            elif line.startswith('Use: '):
                # If it does, store the set of variables in the use variable
                use = set(line.split('Use: ')[1].strip("{}").split(','))
                use.discard('')

            # Check if the line contains the set of defined variables for an item
            elif line.startswith('Def: '):
                # If it does, store the set of variables in the definition variable
                definition = set(line.split('Def: ')[1].strip("{}").split(','))
                definition.discard('')

            # Check if the line contains the set of edges for an item
            elif line.startswith('Edges: '):
                # If it does, store the set of edges in the edges variable
                edges = set(line.split('Edges: ')[1].strip("{}").split('),'))
                edges.discard('')

                # Create a dictionary to store the data for this item
                item_dict = {
                    'Dvars': dvars,
                    'Aliases': aliases,
                    'Use': use,
                    'Def': definition,
                    'Edges': edges
                }

                # Store the dictionary in the data_dict with the name as the key
                data_dict[name] = item_dict

                # Reset the variables for the next item
                name = ''
                dvars = set()
                aliases = set()
                use = set()
                definition = set()
                edges = set()

    # Print the resulting dictionary
    # print(data_dict)

    names_less_than_15 = set()
    for name, values in data_dict.items():
        first_def = min(map(int, values['Def']))
        if first_def < 8:
            names_less_than_15.add(name)

    # print(names_less_than_15)

    all_dict = {}

    # Loop through the dictionary created earlier
    for name, info_dict in data_dict.items():
        # Get the counts of elements in "Dvars," "Use," and "Edges"
        dvars_count = len(info_dict["Dvars"])
        use_count = len(info_dict["Use"])
        edges_count = len(info_dict["Edges"])

        # Create a new dictionary to store the counts
        counts = dvars_count + use_count + edges_count;
        # Add the counts dictionary to the count_dict with the name as the key
        all_dict[name] = counts


    global_dict = {}

    # Loop through the dictionary created earlier
    for name, info_dict in data_dict.items():
        if name in names_less_than_15:
            # Get the counts of elements in "Dvars," "Use," and "Edges"
            dvars_count = len(info_dict["Dvars"])
            use_count = len(info_dict["Use"])
            edges_count = len(info_dict["Edges"])

            # Create a new dictionary to store the counts
            counts = dvars_count + use_count + edges_count;
            # Add the counts dictionary to the count_dict with the name as the key
            global_dict[name] = counts

    # Print the count_dict
    # print("global_dict: ", global_dict)


    # get the top-n
    topn= 7

    # for all_dict
    keys_set = set(all_dict.keys())
    top_keys_all = set()
    sorted_all_dict = sorted(all_dict.items(), key=lambda x: x[1], reverse=True)
    if len(keys_set) < topn:
        top_keys_all = keys_set
    else:
        top_keys_all = set(dict(sorted_all_dict[:topn]).keys())
    # print("top_keys_all : ", top_keys_all)

    # for global_dict
    keys_set = set(global_dict.keys())
    top_keys_global = set()
    sorted_global_dict = sorted(global_dict.items(), key=lambda x: x[1], reverse=True)
    if len(keys_set) < topn:
        top_keys_global = keys_set
    else:
        top_keys_global = set(dict(sorted_global_dict[:topn]).keys())
    # print("top_keys_global : ", top_keys_global)

    # find the variable in the printf
    # define a regular expression pattern to match printf statements
    printf_pattern = re.compile(r'printf\s*\(\s*"[^"]*"\s*(?:,\s*(.+)\s*)?\)')

    # open the C source code file
    with open('example.c', 'r') as f:
        code = f.read()

    # find all printf statements in the code
    for match in printf_pattern.finditer(code):
        # extract the variable being printed (if any)
        var = match.group(1)
        # print("len of top_key_all : ", len(top_keys_all))
        if var and len(top_keys_all) >= 2 and len(top_keys_global) >= 2 :
            # print the variable name
            # print('Variable to be printed:', var.strip())
            top_keys_all.discard(var)
            top_keys_global.discard(var)
        # else:
        #     print('No variable to be printed')
    # print("top_keys_all : ", top_keys_all)
     #print("top_keys_global : ", top_keys_global)
    return top_keys_all, top_keys_global

if __name__ == '__main__':
    src_file = './fail.c'
    # top_keys_all, top_keys_global = data_flow_analysis(src_file)
    # print("top_keys_all : ", top_keys_all)
    # print("top_keys_global : ", top_keys_global)
