#!/bin/bash

srcml ./example.c --position -o example.c.xml

srcslice example.c.xml > example.c.dict

# srcml test-struct.c --position -o test-struct.xml
# srcslice test-struct.xml
