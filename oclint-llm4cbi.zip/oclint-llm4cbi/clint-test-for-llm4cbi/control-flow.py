# -*- coding: utf-8 -*-

import os
import sys

def write_dict_to_file(filename, my_dict):
    with open(filename, 'w') as f:
        for key, value in my_dict.items():
            # f.write(str(key) + '\n')
            if isinstance(value, list):
                for item in value:
                    f.write(str(item) + ' ')
            else:
                f.write(str(value) + '\n')
            f.write('\n')

def control_flow_analysis(src_file):
    # ret = set()
    topn = 3
    # os.system("cp {} example.c".format(src_file))
    os.system("rm cyclo*.txt")
    os.system("cp /media/haoxin/sam-disk/fl-compiler/chatIso/clint-test/Makefile .")
    os.system("make clean > /dev/null && bear make > /dev/null")
    os.system("oclint-json-compilation-database -- --enable-global-analysis -report-type=html -o test.html -rc CYCLOMATIC_COMPLEXITY=0 > cyclo-temp.txt")
    # os.system("cat cyclo.txt")
    # get the out from oclint (cyclomatic complexity for each block)
    # read the file and extract the last three columns
    # preprocessing
    # os.system("cat cyclo-temp.txt")
    with open('cyclo-temp.txt', 'r') as file:
        lines = file.readlines()
    d = {}
    for line in lines:
        columns = line.split()
        key = columns[0]
        if len(columns) == 3:
            d[key][1] = columns[2]
        else:
            d[key] = columns[1:]
    write_dict_to_file("cyclo.txt", d)
    # print("-----------")
    # os.system("cat cyclo.txt")
    with open('cyclo.txt', 'r') as f:
        data = []
        for line in f:
            parts = line.split()
            data.append((int(parts[1]), int(parts[2]), int(parts[3])))
    # create a set of the last three columns and order it by the second column
    set_data = set(data)
    ordered_set_data = sorted(set_data, key=lambda x: -x[0])
    # print("ordered_set_data : ", ordered_set_data)
    if len(ordered_set_data) < topn:
        ret = ordered_set_data
    else:
        ret = set(ordered_set_data[:topn])

    return ret

if __name__ == '__main__':
    src_file = "./example.c"
    my_dict = {
    "0x555558292898": ["for", "8", "11", "29"],
    "0x555558292838": ["for", "6", "14", "28"],
    "0x5555582926d0": ["for", "4", "17", "26"],
    "0x555558292670": ["if", "6", "23", "25"],
    "0x555558292bc8": ["if", "2", "33", "35"]}

    # write_dict_to_file("o.txt", my_dict)
    ret = control_flow_analysis(src_file)
    print("ret : ", ret)
